<?php
$host = "localhost"; 
$user = "u226895802_siswa";
$pass = "^A#Z?6S:o";
$nama_db = "u226895802_siswa"; //nama database
$koneksi = mysqli_connect($host, $user, $pass, $nama_db); //pastikan urutan nya seperti ini, jangan tertukar

if (!$koneksi) { //jika tidak terkoneksi maka akan tampil error
    die("Koneksi dengan database gagal: " . mysqli_connect_error());
}
?>