<?php

include 'koneksi.php';

error_reporting(0);
session_start();

if (isset($_SESSION['sebagai'])) {
  if ($_SESSION['sebagai'] == 'admin') {
    header("Location: admin/index.php");
    exit;
  } elseif ($_SESSION['sebagai'] == 'user') {
    header("Location: user/index.php");
    exit;

  }
}

if (isset($_POST['btn-login'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "SELECT * FROM login WHERE username='$username' and password='$password'";
  $result = mysqli_query($koneksi, $sql);
  if (mysqli_num_rows($result) === 1) {
    $_SESSION['username'] = true;
    $rows = mysqli_fetch_assoc($result);
    if ($rows['sebagai'] == 'admin') {
      $_SESSION['sebagai'] = $rows['sebagai'];
      $_SESSION['nama'] = $rows['nama'];
      // $_SESSION['id'] = $rows['password'];
      return header("Location: admin/index.php");

      if (isset($_SESSION['username'])) {
        header("Location: admin/index.php");
        exit;
      }
    } elseif ($rows['sebagai'] == 'user') {
      $_SESSION['sebagai'] = $rows['sebagai'];
      $_SESSION['nama'] = $rows['nama'];
      // $_SESSION['id'] = $rows['password'];
      return header("Location: user/index.php");


      if (isset($_SESSION['username'])) {
        header("Location: user/index.php");
        exit;
      }
    }
  } else {
    echo "<script>alert('username atau password Anda salah. Silahkan coba lagi!')</script>";
  }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="icon" href="assets/img/smkmadya.png">
  <meta charset="UTF-8">
  <title>Absensi | Admin Login</title>
  <link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">

  <style>
    .text-2 {
      color: lightslategray;
      font-weight: bold;
    }

    button {
      padding: 0.7rem;
      background-color: #4e73df;
      color: white;
      border-radius: 10px;
      font-size: medium;
      font-weight: 600;

    }
  </style>

<body>
  <form method="post" id="loginForm" class="login" action="">
    <input type="text" name="username" id="username" placeholder="Username" required>
    <input type="password" name="password" id="password" placeholder="Password" required>
    <input type="hidden" name="latitude" id="latitude">
    <input type="hidden" name="longitude" id="longitude">
    <div class="d-flex align-items-center">
      <button type="button" class="btn btn-primary" onclick="getLocation()">Get Location</button>
      <button type="submit" class="btn-login" name="btn-login"">Login</button>

    </div>
    <a href="index.php" class="text-2">Go to Siswa Page</a>
  </form>

</body>