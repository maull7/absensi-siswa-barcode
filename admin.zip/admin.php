<?php
include 'koneksi.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Define allowed location coordinates
$allowed_latitude = -6.4088336; // Adjust with the correct coordinates
$allowed_longitude = 106.9019596; // Adjust with the correct coordinates
$allowed_radius = 300 / 111320; // About 0.009, adjust radius (in degrees)

if (isset($_POST['login'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $latitude = $_POST['latitude'];
  $longitude = $_POST['longitude'];

  if (!$latitude && !$longitude) {
    echo "<script>
    alert('Tolong ambil lokasi terlebih dahulu')
    window.location.href = 'admin.php'
    </script>";
  }

  // Check if the user is within the allowed area
  if (abs($latitude - $allowed_latitude) <= $allowed_radius && abs($longitude - $allowed_longitude) <= $allowed_radius) {
    // Directly incorporate the variable into the query (not recommended)
    $query = "SELECT * FROM login WHERE username='$username'";
    $result = $koneksi->query($query);

    if ($result->num_rows === 1) {
      $rows = $result->fetch_assoc();
      // Directly compare passwords (not secure)
      if ($password === $rows['password']) {
        $_SESSION['sebagai'] = $rows['sebagai'];
        $_SESSION['username'] = true;
        $_SESSION['nama'] = $rows['nama'];

        if ($rows['sebagai'] == 'admin') {
          header("Location: admin/index.php");
        } elseif ($rows['sebagai'] == 'user') {
          header("Location: user/index.php");
        }
        exit;
      } else {
        echo "<script>alert('Username atau password Anda salah. Silahkan coba lagi!')</script>";
      }
    } else {
      echo "<script>alert('Username atau password Anda salah. Silahkan coba lagi!')</script>";
    }
  } else {
    echo "<script>
    alert('Lokasi anda berada diluar jangkauan SMK MADYA DEPOK')
    window.location.href = 'admin.php'
    </script>";
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="icon" href="assets/img/smkmadya.png">
  <meta charset="UTF-8">
  <title>Absensi | Admin Login</title>
  <link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">

  <style>
    .text-2 {
      color: lightslategray;
      font-weight: bold;
    }

    button {
      padding: 0.7rem;
      background-color: #4e73df;
      color: white;
      border-radius: 10px;
      font-size: medium;
      font-weight: 600;

    }
  </style>

<body>
  <form method="post" id="loginForm" class="login" action="">
    <input type="text" name="username" id="username" placeholder="Username" required>
    <input type="password" name="password" id="password" placeholder="Password" required>
    <input type="hidden" name="latitude" id="latitude">
    <input type="hidden" name="longitude" id="longitude">
    <div class="d-flex align-items-center">
      <button type="button" class="btn btn-primary" onclick="getLocation()">Get Location</button>
      <button type="submit" class="btn-login" name="login" onclick="submitForm()">Login</button>

    </div>
    <a href="index.php" class="text-2">Go to Siswa Page</a>
  </form>

  <script>
    let locationCaptured = false;

    function getLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
          const userLatitude = position.coords.latitude;
          const userLongitude = position.coords.longitude;
          document.getElementById('latitude').value = userLatitude;
          document.getElementById('longitude').value = userLongitude;
          locationCaptured = true;
          alert("Location captured successfully!");
          console.log('user latitude : ' + userLatitude);
          console.log('user longitude : ' + userLongitude);
        }, function(error) {
          alert("Tidak dapat mengakses lokasi Anda. Pastikan izin lokasi diaktifkan.");
          console.log("Geolocation error: ", error);
        }, {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 5000
        });
      } else {
        alert("Geolocation tidak didukung oleh browser ini.");
      }
    }

    function submitForm() {
      if (locationCaptured) {
        document.getElementById('loginForm').submit();
      } else {
        alert("Please capture your location first.");
      }
    }
  </script>
</body>